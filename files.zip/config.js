// Blip configuration
// Alpha version: hardcoded values. Future: populated from chrome.storage via sidebar UI.

const BLIP_CONFIG = {
  // GitHub settings
  github: {
    owner: 'YOUR_GITHUB_USERNAME',
    repo: 'YOUR_REPO_NAME',
    branch: 'main',
    filePath: 'index.html',
    token: 'YOUR_PERSONAL_ACCESS_TOKEN'
  },

  // Site matching
  site: {
    url: 'remaphq.com'
  },

  // Sidebar settings
  sidebar: {
    widthPercent: 18,
    minWidthPx: 220,
    maxWidthPx: 360
  },

  // Dev mode
  dev: {
    enabled: true,
    showNotifications: true
  },

  // MutationObserver settings
  observer: {
    settleDelayMs: 150,
    trackOnlyUserInitiated: true
  }
};
